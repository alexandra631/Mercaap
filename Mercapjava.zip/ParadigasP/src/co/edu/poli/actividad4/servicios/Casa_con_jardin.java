package co.edu.poli.actividad4.servicios;

import co.edu.poli.actividad3.modelo.Casa;

import java.io.*;
import java.util.*;

/**
 * 
 */
public class Casa_con_jardin extends Casa {

    /**
     * Default constructor
     */
    public Casa_con_jardin() {
    }

    /**
     * 
     */
    private String tipodevegetacion;

}