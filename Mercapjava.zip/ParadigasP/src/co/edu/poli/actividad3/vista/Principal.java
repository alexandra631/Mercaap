package co.edu.poli.actividad3.vista;

import java.io.*;
import java.util.*;

/**
 * 
 */
class Principal {

    /**
     * Default constructor
     */
    Principal() {
    }

    /**
     * @param args 
     * @return
     */
    public static Void  main(String [ ] args) {
        // TODO implement here
        return null;
    }

}