package co.edu.poli.actividad3.modelo;

import java.io.*;
import java.util.*;

/**
 * 
 */
public class Localizacion {

    /**
     * Default constructor
     */
    public Localizacion() {
    }

    /**
     * 
     */
    private double longitud;

    /**
     * 
     */
    private double latitud;

    /**
    
     */
    public void consultar() {
        // TODO implement here
    }

    /**
  
     */
    public void RegistrarArea() {
        // TODO implement here
    }

}