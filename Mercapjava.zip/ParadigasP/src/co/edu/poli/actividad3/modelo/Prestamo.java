package co.edu.poli.actividad3.modelo;

import java.io.*;
import java.util.*;

/**
 * 
 */
public class Prestamo {

    /**
     * Default constructor
     */
    public Prestamo() {
    }

    /**
     * 
     */
    private int fecha_prestamo;

    /**
     * 
     */
    private int fecha_entrega;

    /**
     * 
     */
    private Usuario usuario;

    /**
     * 
     */
    private String numero_prestamo;

    /**
     * 
     */
    private String costo_prestamo;

    /**
     * 
     */
    private String porcentaje_tasa_prestamo;

    /**
     * 
     */
    private Vivienda vivienda;

}