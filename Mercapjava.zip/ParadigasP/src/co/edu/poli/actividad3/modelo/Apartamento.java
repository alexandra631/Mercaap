package co.edu.poli.actividad3.modelo;

import java.io.*;
import java.util.*;

/**
 * 
 */
public class Apartamento extends Vivienda {


    /**
     * 
     */
    private int numero_de_piso;

    /**
     * 
     */
    private boolean tiene_acensor ;

    /**
     * 
     */
    private String numeroapartamento;

	public Apartamento(int numero_de_piso, boolean tiene_acensor, String numeroapartamento) {
		super();
		this.numero_de_piso = numero_de_piso;
		this.tiene_acensor = tiene_acensor;
		this.numeroapartamento = numeroapartamento;
	}

	public int getNumero_de_piso() {
		return numero_de_piso;
	}

	public void setNumero_de_piso(int numero_de_piso) {
		this.numero_de_piso = numero_de_piso;
	}

	public boolean isTiene_acensor() {
		return tiene_acensor;
	}

	public void setTiene_acensor(boolean tiene_acensor) {
		this.tiene_acensor = tiene_acensor;
	}

	public String getNumeroapartamento() {
		return numeroapartamento;
	}

	public void setNumeroapartamento(String numeroapartamento) {
		this.numeroapartamento = numeroapartamento;
	
	}

	@Override
	public String toString() {
		return "Apartamento [numero_de_piso=" + numero_de_piso + ", tiene_acensor=" + tiene_acensor
				+ ", numeroapartamento=" + numeroapartamento + ", toString()=" + super.toString() + "]";
	}

}