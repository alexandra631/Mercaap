package co.edu.poli.actividad3.modelo;

import java.io.*;
import java.util.*;

/**
 * 
 */
public class Usuario {

    /**
     * Default constructor
     */
    public Usuario() {
    }

    /**
     * 
     */
    private String nombre;

    /**
     * 
     */
    private String documento;

    /**
     * 
     */
    private String direccion_residencia;

    /**
     * 
     */
    private String telefono;

    /**
     * 
     */
    private int edad;

    /**
     * @param usuario 
     * @param telefono 
     * @param ubicacion
     */
    public void RegistrarUsuario(void usuario, void telefono, void ubicacion) {
        // TODO implement here
    }

    /**
     * @param usuario 
     * @param telefono 
     * @param ubicacion
     */
    public void actualizar(void usuario, void telefono, void ubicacion) {
        // TODO implement here
    }

    /**
     * @return
     */
    private String ahora() {
        // TODO implement here
        return "";
    }

	public Usuario(String nombre, String documento, String direccion_residencia, String telefono, int edad) {
		super();
		this.nombre = nombre;
		this.documento = documento;
		this.direccion_residencia = direccion_residencia;
		this.telefono = telefono;
		this.edad = edad;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public String getDocumento() {
		return documento;
	}

	public void setDocumento(String documento) {
		this.documento = documento;
	}

	public String getDireccion_residencia() {
		return direccion_residencia;
	}

	public void setDireccion_residencia(String direccion_residencia) {
		this.direccion_residencia = direccion_residencia;
	}

	public String getTelefono() {
		return telefono;
	}

	public void setTelefono(String telefono) {
		this.telefono = telefono;
	}

	public int getEdad() {
		return edad;
	}

	public void setEdad(int edad) {
		this.edad = edad;
	}

	@Override
	public String toString() {
		return "Usuario [nombre=" + nombre + ", documento=" + documento + ", direccion_residencia="
				+ direccion_residencia + ", telefono=" + telefono + ", edad=" + edad + "]";
	}

}