package co.edu.poli.actividad3.modelo;

import java.io.*;
import java.util.*;

/**
 * 
 */
public class Casa extends Vivienda {

    /**
     * 
     */
    private String cantidad_pisos_de_casa;

    /**
     * 
     */
    private boolean casa_tiene_garaje;

	public Casa(String cantidad_habitaciones, String cantidad_baños, String tamaño_cocina, String dimensio_vivienda,
			Localizacion localizacion, boolean nombre_dueño_vivienda, boolean contacto_dueño_vivienda,
			String experencias_usuarios, String administrador_vivienda, String numero_predial,
			String cantidad_pisos_de_casa, boolean casa_tiene_garaje) {
		super(cantidad_habitaciones, cantidad_baños, tamaño_cocina, dimensio_vivienda, localizacion,
				nombre_dueño_vivienda, contacto_dueño_vivienda, experencias_usuarios, administrador_vivienda,
				numero_predial);
		this.cantidad_pisos_de_casa = cantidad_pisos_de_casa;
		this.casa_tiene_garaje = casa_tiene_garaje;
	}

	public String getCantidad_pisos_de_casa() {
		return cantidad_pisos_de_casa;
	}

	public void setCantidad_pisos_de_casa(String cantidad_pisos_de_casa) {
		this.cantidad_pisos_de_casa = cantidad_pisos_de_casa;
	}

	public boolean isCasa_tiene_garaje() {
		return casa_tiene_garaje;
	}

	public void setCasa_tiene_garaje(boolean casa_tiene_garaje) {
		this.casa_tiene_garaje = casa_tiene_garaje;
	}

	@Override
	public String toString() {
		return "Casa [cantidad_pisos_de_casa=" + cantidad_pisos_de_casa + ", casa_tiene_garaje=" + casa_tiene_garaje
				+ ", toString()=" + super.toString() + "]";
	}

}