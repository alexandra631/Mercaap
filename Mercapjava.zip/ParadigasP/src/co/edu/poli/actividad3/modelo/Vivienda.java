package co.edu.poli.actividad3.modelo;

import java.io.*;
import java.util.*;

/**
 * 
 */
public class Vivienda {



    /**
     * 
     */
    private String cantidad_habitaciones;

    /**
     * 
     */
    private String cantidad_baños;

    /**
     * 
     */
    private String tamaño_cocina;

    /**
     * 
     */
    private String dimensio_vivienda;

    /**
     * 
     */
    private Localizacion localizacion;

    /**
     * 
     */
    private boolean nombre_dueño_vivienda;

    /**
     * 
     */
    private boolean contacto_dueño_vivienda;

    /**
     * 
     */
    private String experencias_usuarios;

    /**
     * 
     */
    private String administrador_vivienda;

    /**
     * 
     */
    private String numero_predial;

    /**
     * @param tamaño_vivienda 
     * @return
     */
    protected String mostrar_tamaño(String tamaño_vivienda) {
        // TODO implement here
        return "";
    }

    /**
     * @param tamaño_vivienda 
     * @param tamaño_habitacion 
     * @return
     */
    protected String mostrar_tamaño(String tamaño_vivienda, String tamaño_habitacion) {
        // TODO implement here
        return "";
    }

	public Vivienda(String cantidad_habitaciones, String cantidad_baños, String tamaño_cocina, String dimensio_vivienda,
			Localizacion localizacion, boolean nombre_dueño_vivienda, boolean contacto_dueño_vivienda,
			String experencias_usuarios, String administrador_vivienda, String numero_predial) {
		super();
		this.cantidad_habitaciones = cantidad_habitaciones;
		this.cantidad_baños = cantidad_baños;
		this.tamaño_cocina = tamaño_cocina;
		this.dimensio_vivienda = dimensio_vivienda;
		this.localizacion = localizacion;
		this.nombre_dueño_vivienda = nombre_dueño_vivienda;
		this.contacto_dueño_vivienda = contacto_dueño_vivienda;
		this.experencias_usuarios = experencias_usuarios;
		this.administrador_vivienda = administrador_vivienda;
		this.numero_predial = numero_predial;
	}

	public String getCantidad_habitaciones() {
		return cantidad_habitaciones;
	}

	public void setCantidad_habitaciones(String cantidad_habitaciones) {
		this.cantidad_habitaciones = cantidad_habitaciones;
	}

	public String getCantidad_baños() {
		return cantidad_baños;
	}

	public void setCantidad_baños(String cantidad_baños) {
		this.cantidad_baños = cantidad_baños;
	}

	public String getTamaño_cocina() {
		return tamaño_cocina;
	}

	public void setTamaño_cocina(String tamaño_cocina) {
		this.tamaño_cocina = tamaño_cocina;
	}

	public String getDimensio_vivienda() {
		return dimensio_vivienda;
	}

	public void setDimensio_vivienda(String dimensio_vivienda) {
		this.dimensio_vivienda = dimensio_vivienda;
	}

	public Localizacion getLocalizacion() {
		return localizacion;
	}

	public void setLocalizacion(Localizacion localizacion) {
		this.localizacion = localizacion;
	}

	public boolean isNombre_dueño_vivienda() {
		return nombre_dueño_vivienda;
	}

	public void setNombre_dueño_vivienda(boolean nombre_dueño_vivienda) {
		this.nombre_dueño_vivienda = nombre_dueño_vivienda;
	}

	public boolean isContacto_dueño_vivienda() {
		return contacto_dueño_vivienda;
	}

	public void setContacto_dueño_vivienda(boolean contacto_dueño_vivienda) {
		this.contacto_dueño_vivienda = contacto_dueño_vivienda;
	}

	public String getExperencias_usuarios() {
		return experencias_usuarios;
	}

	public void setExperencias_usuarios(String experencias_usuarios) {
		this.experencias_usuarios = experencias_usuarios;
	}

	public String getAdministrador_vivienda() {
		return administrador_vivienda;
	}

	public void setAdministrador_vivienda(String administrador_vivienda) {
		this.administrador_vivienda = administrador_vivienda;
	}

	public String getNumero_predial() {
		return numero_predial;
	}

	public void setNumero_predial(String numero_predial) {
		this.numero_predial = numero_predial;
	}

	@Override
	public String toString() {
		return "Vivienda [cantidad_habitaciones=" + cantidad_habitaciones + ", cantidad_baños=" + cantidad_baños
				+ ", tamaño_cocina=" + tamaño_cocina + ", dimensio_vivienda=" + dimensio_vivienda + ", localizacion="
				+ localizacion + ", nombre_dueño_vivienda=" + nombre_dueño_vivienda + ", contacto_dueño_vivienda="
				+ contacto_dueño_vivienda + ", experencias_usuarios=" + experencias_usuarios
				+ ", administrador_vivienda=" + administrador_vivienda + ", numero_predial=" + numero_predial
				+ ", getCantidad_habitaciones()=" + getCantidad_habitaciones() + ", getCantidad_baños()="
				+ getCantidad_baños() + ", getTamaño_cocina()=" + getTamaño_cocina() + ", getDimensio_vivienda()="
				+ getDimensio_vivienda() + ", getLocalizacion()=" + getLocalizacion() + ", isNombre_dueño_vivienda()="
				+ isNombre_dueño_vivienda() + ", isContacto_dueño_vivienda()=" + isContacto_dueño_vivienda()
				+ ", getExperencias_usuarios()=" + getExperencias_usuarios() + ", getAdministrador_vivienda()="
				+ getAdministrador_vivienda() + ", getNumero_predial()=" + getNumero_predial() + ", getClass()="
				+ getClass() + ", hashCode()=" + hashCode() + ", toString()=" + super.toString() + "]";
	}

}