package co.edu.poli.actividad4.servicios;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

import co.edu.poli.actividad3.modelo.Usuario;

public class ImplementacionOperacion implements Operacion {

    private Usuario[] usuarios;

    public ImplementacionOperacion() {
        // Initialize the array with a size of 5
        usuarios = new Usuario[5];
    }

    // Create (add a new user if there's space)
    @Override
    public String create(Usuario nuevoUsuario) {
        for (int i = 0; i < usuarios.length; i++) {
            if (usuarios[i] == null) { // Check if there's an available space
                usuarios[i] = nuevoUsuario;
                return "Usuario creado con éxito.";
            }
        }
        return "Error: No hay espacio para crear más usuarios.";
    }

    // Read a user by ID
    @Override
    public Usuario read(String id) {
        for (int i = 0; i < usuarios.length; i++) {
            if (usuarios[i] != null && usuarios[i].getId().equals(id)) {
                return usuarios[i];
            }
        }
        return null; // Returns null if the user is not found
    }

    // Read all users
    @Override
    public Usuario[] readall() {
        return usuarios; // Returns the entire array
    }

    // Update a user by ID
    @Override
    public String update(Usuario usuarioActualizado, String id) {
        for (int i = 0; i < usuarios.length; i++) {
            if (usuarios[i] != null && usuarios[i].getId().equals(id)) {
                usuarios[i] = usuarioActualizado; // Update the user at the found position
                return "Usuario actualizado con éxito.";
            }
        }
        return "Error: Usuario no encontrado.";
    }

    // Delete a user by ID
    @Override
    public Usuario delete(String id) {
        for (int i = 0; i < usuarios.length; i++) {
            if (usuarios[i] != null && usuarios[i].getId().equals(id)) {
                Usuario usuarioEliminado = usuarios[i]; // Save the deleted user to return it
                usuarios[i] = null; // Delete the user by setting it to null
                return usuarioEliminado; // Return the deleted user
            }
        }
        return null; // Returns null if the user is not found
    }

    public String serializar(Usuario[] usuarios, String path, String name) {
        try {
            // Asegúrate de que la ruta termine con un separador de directorio
            FileOutputStream fos = new FileOutputStream(path + name);
            ObjectOutputStream oos = new ObjectOutputStream(fos);
            oos.writeObject(usuarios);
            oos.close();
            fos.close();
            return "Archivo creado con éxito.";
        } catch (IOException ioe) {
            return "Error al crear archivo: " + ioe.getMessage();
        }
    }

    
    public Usuario[] deserializar(String path, String name) {
        Usuario[] usuarios = null;
        try {
            FileInputStream fis = new FileInputStream(path + name);
            ObjectInputStream ois = new ObjectInputStream(fis);
            usuarios = (Usuario[]) ois.readObject(); // Cambiado a Usuario[]
            ois.close();
            fis.close();
        } catch (IOException ioe) {
            ioe.printStackTrace();
        } catch (ClassNotFoundException c) {
            c.printStackTrace();
        }
        return usuarios; // Retorna el arreglo de usuarios
    }

    // Getter for the array of users
    public Usuario[] getUsuarios() {
        return usuarios;
    }

    // Setter for the array of users
    public void setUsuarios(Usuario[] usuarios) {
        this.usuarios = usuarios;
    }
}
