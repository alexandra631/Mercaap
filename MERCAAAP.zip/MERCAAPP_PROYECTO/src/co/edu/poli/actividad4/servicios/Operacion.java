package co.edu.poli.actividad4.servicios;

import co.edu.poli.actividad3.modelo.Usuario;

public interface Operacion {

    /**
     * Creates a new user.
     * @param x The user to be created.
     * @return A message indicating success or failure.
     */
    public String create(Usuario x);

    /**
     * Reads a user by their ID.
     * @param id The ID of the user to be read.
     * @return The user object if found, otherwise null.
     */
    public Usuario read(String id);

    /**
     * Reads all users.
     * @return An array of all users.
     */
    public Usuario[] readall();

    /**
     * Updates a user with the specified ID.
     * @param x The updated user data.
     * @param id The ID of the user to be updated.
     * @return A message indicating success or failure.
     */
    public String update(Usuario x, String id);

    /**
     * Deletes a user by their ID.
     * @param id The ID of the user to be deleted.
     * @return The deleted user object if found, otherwise null.
     */
    public Usuario delete(String id);

    /**
     * Serializes the array of users to a file.
     * @param usuarios The array of users to be serialized.
     * @param path The path where the file should be saved.
     * @param name The name of the file.
     * @return A message indicating success or failure.
     */
    public String serializar(Usuario[] usuarios, String path, String name);

    /**
     * Deserializes the array of users from a file.
     * @param path The path where the file is located.
     * @param name The name of the file.
     * @return The array of deserialized users, or null if an error occurs.
     */
    public Usuario[] deserializar(String path, String name);
}