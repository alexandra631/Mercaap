package co.edu.poli.actividad3.modelo;

import java.io.*;
import java.util.*;

/**
 * 
 */

	public class Usuario extends Consumidor implements Serializable {
	    private static final long serialVersionUID = 1L;
 
    /**
     * 
     */
    private String  nombre;

    /**
     * 
     */
    private String email;

    /**
     * 
     */
    private String direccion;

    /**
     * 
     */
    private String telefono;

    /**
     * 
     */
    private Productor productor;

    /**
     * 
     */
    private Consumidor consumidor;

    /**
     * 
     */
    private String Id;

    /**
     * @return
     */
    public String editar_perfil() {
        // TODO implement here
        return "";
    }


	public String getNombre() {
		return nombre;
	}


	public void setNombre(String nombre) {
		this.nombre = nombre;
	}


	public String getEmail() {
		return email;
	}


	public void setEmail(String email) {
		this.email = email;
	}


	public String getDireccion() {
		return direccion;
	}


	public void setDireccion(String direccion) {
		this.direccion = direccion;
	}


	public String getTelefono() {
		return telefono;
	}


	public void setTelefono(String telefono) {
		this.telefono = telefono;
	}


	public Productor getProductor() {
		return productor;
	}


	public void setProductor(Productor productor) {
		this.productor = productor;
	}


	public Consumidor getConsumidor() {
		return consumidor;
	}


	public void setConsumidor(Consumidor consumidor) {
		this.consumidor = consumidor;
	}


	public String getId() {
		return Id;
	}


	public void setId(String id) {
		Id = id;
	}


	@Override
	public String toString() {
		return "Usuario [nombre=" + nombre + ", email=" + email + ", direccion=" + direccion + ", telefono=" + telefono
				+ ", productor=" + productor + ", consumidor=" + consumidor + ", Id=" + Id + "]";
	}


	public Usuario(String metodo_pago, String nombre, String email, String direccion, String telefono,
			Productor productor, Consumidor consumidor, String id) {
		super(metodo_pago);
		this.nombre = nombre;
		this.email = email;
		this.direccion = direccion;
		this.telefono = telefono;
		this.productor = productor;
		this.consumidor = consumidor;
		Id = id;
	}


	

	
}