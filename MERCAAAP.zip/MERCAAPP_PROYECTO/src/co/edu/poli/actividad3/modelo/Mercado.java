package co.edu.poli.actividad3.modelo;

import java.io.*;
import java.util.*;

/**
 * 
 */
public class Mercado {



    /**
     * 
     */
    private String nombre;

    /**
     * 
     */
    private String ubicacion;

    /**
     * 
     */
    private String fechaInicio;

    /**
     * 
     */
    private String fechaFin;

    /**
     * 
     */
    public Productor productores;

    /**
     * @param fecha_inicio 
     * @param fecha_fin 
     * @return
     */
    public String reporte_ventas(String fecha_inicio, String fecha_fin) {
        // TODO implement here
        return "";
    }

	public Mercado(String nombre, String ubicacion, String fechaInicio, String fechaFin, Productor productores) {
		super();
		this.nombre = nombre;
		this.ubicacion = ubicacion;
		this.fechaInicio = fechaInicio;
		this.fechaFin = fechaFin;
		this.productores = productores;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public String getUbicacion() {
		return ubicacion;
	}

	public void setUbicacion(String ubicacion) {
		this.ubicacion = ubicacion;
	}

	public String getFechaInicio() {
		return fechaInicio;
	}

	public void setFechaInicio(String fechaInicio) {
		this.fechaInicio = fechaInicio;
	}

	public String getFechaFin() {
		return fechaFin;
	}

	public void setFechaFin(String fechaFin) {
		this.fechaFin = fechaFin;
	}

	public Productor getProductores() {
		return productores;
	}

	public void setProductores(Productor productores) {
		this.productores = productores;
	}

	@Override
	public String toString() {
		return "Mercado [nombre=" + nombre + ", ubicacion=" + ubicacion + ", fechaInicio=" + fechaInicio + ", fechaFin="
				+ fechaFin + ", productores=" + productores + "]";
	}

}