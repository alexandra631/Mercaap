package co.edu.poli.actividad3.modelo;

import java.io.*;
import java.util.*;

/**
 * 
 */
public class Producto {


    /**
     * 
     */
    private String nombre;

    /**
     * 
     */
    private String descripcion;

    /**
     * 
     */
    private Float precio;

    /**
     * 
     */
    private int cantidadDisponible;

    /**
     * 
     */
    private String Categoria;


    /**
     * @param cantidad_deseada 
     * @return
     */
    public boolean verificar_disponiblidad(int cantidad_deseada) {
        // TODO implement here
        return false;
    }


	public Producto(String nombre, String descripcion, Float precio, int cantidadDisponible, String categoria) {
		super();
		this.nombre = nombre;
		this.descripcion = descripcion;
		this.precio = precio;
		this.cantidadDisponible = cantidadDisponible;
		Categoria = categoria;
	}


	public String getNombre() {
		return nombre;
	}


	public void setNombre(String nombre) {
		this.nombre = nombre;
	}


	public String getDescripcion() {
		return descripcion;
	}


	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}


	public Float getPrecio() {
		return precio;
	}


	public void setPrecio(Float precio) {
		this.precio = precio;
	}


	public int getCantidadDisponible() {
		return cantidadDisponible;
	}


	public void setCantidadDisponible(int cantidadDisponible) {
		this.cantidadDisponible = cantidadDisponible;
	}


	public String getCategoria() {
		return Categoria;
	}


	public void setCategoria(String categoria) {
		Categoria = categoria;
	}


	@Override
	public String toString() {
		return "Producto [nombre=" + nombre + ", descripcion=" + descripcion + ", precio=" + precio
				+ ", cantidadDisponible=" + cantidadDisponible + ", Categoria=" + Categoria + "]";
	}

}