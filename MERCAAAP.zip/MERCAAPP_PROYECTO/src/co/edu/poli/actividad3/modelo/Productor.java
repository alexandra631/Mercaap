package co.edu.poli.actividad3.modelo;

import java.io.*;
import java.util.*;

/**
 * 
 */
public class Productor {

  

    /**
     * 
     */
    private Producto productos;

    /**
     * 
     */
    private String ubicacion;

    /**
     * 
     */
    private String metodoDeProduccion;

    /**
     * 
     */
    private Float calificacion;

    /**
     * @param fecha_inicio 
     * @param fecha_fin 
     * @return
     */
    public String calcular_ingresos(float fecha_inicio, String fecha_fin) {
        // TODO implement here
        return "";
    }

	public Productor(Producto productos, String ubicacion, String metodoDeProduccion, Float calificacion) {
		super();
		this.productos = productos;
		this.ubicacion = ubicacion;
		this.metodoDeProduccion = metodoDeProduccion;
		this.calificacion = calificacion;
	}

	public Producto getProductos() {
		return productos;
	}

	public void setProductos(Producto productos) {
		this.productos = productos;
	}

	public String getUbicacion() {
		return ubicacion;
	}

	public void setUbicacion(String ubicacion) {
		this.ubicacion = ubicacion;
	}

	public String getMetodoDeProduccion() {
		return metodoDeProduccion;
	}

	public void setMetodoDeProduccion(String metodoDeProduccion) {
		this.metodoDeProduccion = metodoDeProduccion;
	}

	public Float getCalificacion() {
		return calificacion;
	}

	public void setCalificacion(Float calificacion) {
		this.calificacion = calificacion;
	}

	@Override
	public String toString() {
		return "Productor [productos=" + productos + ", ubicacion=" + ubicacion + ", metodoDeProduccion="
				+ metodoDeProduccion + ", calificacion=" + calificacion + ", getProductos()=" + getProductos()
				+ ", getUbicacion()=" + getUbicacion() + ", getMetodoDeProduccion()=" + getMetodoDeProduccion()
				+ ", getCalificacion()=" + getCalificacion() + ", getClass()=" + getClass() + ", hashCode()="
				+ hashCode() + ", toString()=" + super.toString() + "]";
	}

}