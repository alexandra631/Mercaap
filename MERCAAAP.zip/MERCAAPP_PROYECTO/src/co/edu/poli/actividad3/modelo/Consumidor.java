package co.edu.poli.actividad3.modelo;

import java.io.*;
import java.util.*;

/**
 * 
 */
public class Consumidor {

  
    /**
     * 
     */
    private String metodo_pago;

    /**
     * @param mes 
     * @param ano 
     * @return
     */
    public float calculara_gastos_mensuales(int mes, int ano) {
        // TODO implement here
        return 0.0f;
    }

	public Consumidor(String metodo_pago) {
		super();
		this.metodo_pago = metodo_pago;
	}

	public String getMetodo_pago() {
		return metodo_pago;
	}

	public void setMetodo_pago(String metodo_pago) {
		this.metodo_pago = metodo_pago;
	}

	@Override
	public String toString() {
		return "Consumidor [metodo_pago=" + metodo_pago + ", getMetodo_pago()=" + getMetodo_pago() + ", getClass()="
				+ getClass() + ", hashCode()=" + hashCode() + ", toString()=" + super.toString() + "]";
	}

}