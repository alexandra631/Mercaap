package co.edu.poli.actividad3.vista;

import java.io.*;
import java.util.*;

import co.edu.poli.actividad3.modelo.Usuario;
import co.edu.poli.actividad4.servicios.ImplementacionOperacion;

/**
 * 
 */
public class Principal {
    public static void main(String[] args) {
        ImplementacionOperacion operaciones = new ImplementacionOperacion();
        Scanner scanner = new Scanner(System.in);
        int opcion;
        String path = "";
        String file = "TextNoBinary1.txt";

        do {
            System.out.println("\n--- Menú de Opciones ---");
            System.out.println("1. Crear usuario");
            System.out.println("2. Leer usuario");
            System.out.println("3. Actualizar usuario");
            System.out.println("4. Eliminar usuario");
            System.out.println("5. Listar todos los usuarios");
            System.out.println("6. Serializar usuarios");
            System.out.println("7. Deserializar usuarios");
            System.out.println("8. Salir");
            System.out.print("Seleccione una opción: ");
            opcion = scanner.nextInt();
            scanner.nextLine(); // Consumir el salto de línea

            switch (opcion) {
                case 1: // Crear usuario
                    System.out.print("Ingrese nombre: ");
                    String nombre = scanner.nextLine();
                    System.out.print("Ingrese email: ");
                    String email = scanner.nextLine();
                    System.out.print("Ingrese dirección: ");
                    String direccion = scanner.nextLine();
                    System.out.print("Ingrese teléfono: ");
                    String telefono = scanner.nextLine();
                    System.out.print("Ingrese ID: ");
                    String id = scanner.nextLine();

                    Usuario nuevoUsuario = new Usuario(null, nombre, email, direccion, telefono, null, null, id);
                    System.out.println(operaciones.create(nuevoUsuario));
                    break;

                case 2: // Leer usuario
                    System.out.print("Ingrese ID del usuario a leer: ");
                    String idLeer = scanner.nextLine();
                    Usuario usuarioLeido = operaciones.read(idLeer);
                    System.out.println("Usuario leído: " + (usuarioLeido != null ? usuarioLeido.toString() : "No se encontró el usuario"));
                    break;

                case 3: // Actualizar usuario
                    System.out.print("Ingrese ID del usuario a actualizar: ");
                    String idActualizar = scanner.nextLine();
                    System.out.print("Ingrese nuevo nombre: ");
                    String nuevoNombre = scanner.nextLine();
                    System.out.print("Ingrese nuevo email: ");
                    String nuevoEmail = scanner.nextLine();
                    System.out.print("Ingrese nueva dirección: ");
                    String nuevaDireccion = scanner.nextLine();
                    System.out.print("Ingrese nuevo teléfono: ");
                    String nuevoTelefono = scanner.nextLine();

                    Usuario usuarioActualizado = new Usuario(null, nuevoNombre, nuevoEmail, nuevaDireccion, nuevoTelefono, null, null, idActualizar);
                    System.out.println(operaciones.update(usuarioActualizado, idActualizar));
                    break;

                case 4: // Eliminar usuario
                    System.out.print("Ingrese ID del usuario a eliminar: ");
                    String idEliminar = scanner.nextLine();
                    Usuario usuarioEliminado = operaciones.delete(idEliminar);
                    System.out.println(usuarioEliminado != null ? "Usuario eliminado con éxito." : "No se encontró el usuario.");
                    break;

                case 5: // Listar todos los usuarios
                    System.out.println("Listando todos los usuarios:");
                    Usuario[] todosLosUsuarios = operaciones.readall();
                    if (todosLosUsuarios != null && todosLosUsuarios.length > 0) {
                        for (Usuario usuario : todosLosUsuarios) {
                            if (usuario != null) {
                                System.out.println(usuario);
                            }
                        }
                    } else {
                        System.out.println("No hay usuarios para mostrar.");
                    }
                    break;

                case 6: // Serializar usuarios
                    
                    System.out.println(operaciones.serializar(operaciones.readall(), path, file));
                    break;

                case 7: // Deserializar usuarios
                    Usuario[] usuariosDeserializados = operaciones.deserializar(path, file);
                    if (usuariosDeserializados != null) {
                        System.out.println("Usuarios deserializados con éxito.");
                        operaciones.setUsuarios(usuariosDeserializados);
                    } else {
                        System.out.println("Error al deserializar usuarios.");
                    }
                    break;

                case 8: // Salir
                    System.out.println("Saliendo del programa...");
                    break;

                default:
                    System.out.println("Opción no válida, por favor intente de nuevo.");
            }
        } while (opcion != 8);

        scanner.close();
    }
}
