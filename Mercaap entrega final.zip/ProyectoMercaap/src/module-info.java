module ProyectoMercaap {
	requires javafx.controls;
	requires javafx.fxml;
	
	opens co.edu.poli.proyecto.controlador to javafx.graphics, javafx.fxml;
	opens co.edu.poli.proyecto.vista to javafx.graphics, javafx.fxml;
}