package co.edu.poli.proyecto.servicios;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

import co.edu.poli.proyecto.modelo.Usuario;

/**
 * Implementa las operaciones CRUD para gestionar un arreglo de objetos Usuario, 
 * ademas de ofrecer metodos de serializacion y deserializacion.
 */
public class ImplementacionOperacion implements Operacion {

    /**
     * Arreglo de objetos Usuario que contiene los usuarios gestionados.
     */
    private Usuario[] usuarios;

    /**
     * Constructor que inicializa el arreglo de usuarios con un tamano de 5.
     */
    public ImplementacionOperacion() {
        usuarios = new Usuario[5];
    }

    /**
     * Crea un nuevo usuario si hay espacio disponible en el arreglo.
     *
     * @param nuevoUsuario El usuario a crear.
     * @return Mensaje indicando el resultado de la operacion.
     */
    @Override
    public String create(Usuario nuevoUsuario) {
        for (int i = 0; i < usuarios.length; i++) {
            if (usuarios[i] == null) {
                usuarios[i] = nuevoUsuario;
                return "Usuario creado con exito.";
            }
        }
        return "Error: No hay espacio para crear mas usuarios.";
    }

    /**
     * Lee un usuario segun su ID.
     *
     * @param id El ID del usuario a leer.
     * @return El usuario encontrado o null si no se encuentra.
     */
    @Override
    public Usuario read(String id) {
        for (Usuario usuario : usuarios) {
            if (usuario != null && usuario.getId().equals(id)) {
                return usuario;
            }
        }
        return null;
    }

    /**
     * Lee todos los usuarios.
     *
     * @return El arreglo completo de usuarios.
     */
    @Override
    public Usuario[] readall() {
        return usuarios;
    }

    /**
     * Actualiza un usuario segun su ID.
     *
     * @param usuarioActualizado El usuario con los datos actualizados.
     * @param id El ID del usuario a actualizar.
     * @return Mensaje indicando el resultado de la operacion.
     */
    @Override
    public String update(Usuario usuarioActualizado, String id) {
        for (int i = 0; i < usuarios.length; i++) {
            if (usuarios[i] != null && usuarios[i].getId().equals(id)) {
                usuarios[i] = usuarioActualizado;
                return "Usuario actualizado con exito.";
            }
        }
        return "Error: Usuario no encontrado.";
    }

    /**
     * Elimina un usuario segun su ID.
     *
     * @param id El ID del usuario a eliminar.
     * @return El usuario eliminado o null si no se encuentra.
     */
    @Override
    public Usuario delete(String id) {
        for (int i = 0; i < usuarios.length; i++) {
            if (usuarios[i] != null && usuarios[i].getId().equals(id)) {
                Usuario usuarioEliminado = usuarios[i];
                usuarios[i] = null;
                return usuarioEliminado;
            }
        }
        return null;
    }

    /**
     * Serializa el arreglo de usuarios a un archivo.
     *
     * @param usuarios Arreglo de usuarios a serializar.
     * @param path Ruta del archivo.
     * @param name Nombre del archivo.
     * @return Mensaje indicando el resultado de la operacion.
     */
    public String serializar(Usuario[] usuarios, String path, String name) {
        try {
            FileOutputStream fos = new FileOutputStream(path + name);
            ObjectOutputStream oos = new ObjectOutputStream(fos);
            oos.writeObject(usuarios);
            oos.close();
            fos.close();
            return "Archivo creado con exito.";
        } catch (IOException ioe) {
            return "Error al crear archivo: " + ioe.getMessage();
        }
    }

    /**
     * Deserializa un archivo para obtener un arreglo de usuarios.
     *
     * @param path Ruta del archivo.
     * @param name Nombre del archivo.
     * @return Arreglo de usuarios deserializado.
     */
    public Usuario[] deserializar(String path, String name) {
        Usuario[] usuarios = null;
        try {
            FileInputStream fis = new FileInputStream(path + name);
            ObjectInputStream ois = new ObjectInputStream(fis);
            usuarios = (Usuario[]) ois.readObject();
            ois.close();
            fis.close();
        } catch (IOException ioe) {
            ioe.printStackTrace();
        } catch (ClassNotFoundException c) {
            c.printStackTrace();
        }
        return usuarios;
    }

    /**
     * Obtiene el arreglo de usuarios.
     *
     * @return El arreglo de usuarios.
     */
    public Usuario[] getUsuarios() {
        return usuarios;
    }

    /**
     * Establece el arreglo de usuarios.
     *
     * @param usuarios Nuevo arreglo de usuarios.
     */
    public void setUsuarios(Usuario[] usuarios) {
        this.usuarios = usuarios;
    }
}
