package co.edu.poli.proyecto.servicios;

import co.edu.poli.proyecto.modelo.Usuario;

/**
 * Define las operaciones CRUD para la gestion de objetos Usuario, asi como metodos para serializacion y deserializacion.
 */
public interface Operacion {

    /**
     * Crea un nuevo usuario.
     *
     * @param x El usuario a ser creado.
     * @return Un mensaje que indica el exito o fracaso de la operacion.
     */
    public String create(Usuario x);

    /**
     * Lee un usuario segun su ID.
     *
     * @param id El ID del usuario a leer.
     * @return El objeto Usuario si es encontrado, de lo contrario null.
     */
    public Usuario read(String id);

    /**
     * Lee todos los usuarios.
     *
     * @return Un arreglo de todos los usuarios.
     */
    public Usuario[] readall();

    /**
     * Actualiza un usuario con el ID especificado.
     *
     * @param x Los datos actualizados del usuario.
     * @param id El ID del usuario a ser actualizado.
     * @return Un mensaje que indica el exito o fracaso de la operacion.
     */
    public String update(Usuario x, String id);

    /**
     * Elimina un usuario segun su ID.
     *
     * @param id El ID del usuario a ser eliminado.
     * @return El objeto Usuario eliminado si es encontrado, de lo contrario null.
     */
    public Usuario delete(String id);

    /**
     * Serializa el arreglo de usuarios a un archivo.
     *
     * @param usuarios El arreglo de usuarios a ser serializado.
     * @param path La ruta donde se debe guardar el archivo.
     * @param name El nombre del archivo.
     * @return Un mensaje que indica el exito o fracaso de la operacion.
     */
    public String serializar(Usuario[] usuarios, String path, String name);

    /**
     * Deserializa el arreglo de usuarios desde un archivo.
     *
     * @param path La ruta donde se encuentra el archivo.
     * @param name El nombre del archivo.
     * @return El arreglo de usuarios deserializado, o null si ocurre un error.
     */
    public Usuario[] deserializar(String path, String name);
}
