package co.edu.poli.proyecto.controlador;

import co.edu.poli.proyecto.modelo.Usuario;
import co.edu.poli.proyecto.servicios.ImplementacionOperacion;
import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.control.Alert.AlertType;

public class InterfazControlador {

    @FXML
    private Button Btt1;

    @FXML
    private Button Btt2;

    @FXML
    private Button Btt3;

    @FXML
    private Button Btt4;

    @FXML
    private Button Btt5;

    @FXML
    private Button Btt6;

    @FXML
    private Button Btt7;

    @FXML
    private Button Btt8;

    @FXML
    private TextField TxtField1;

    @FXML
    private TextField TxtField2;

    @FXML
    private TextField TxtField3;

    @FXML
    private TextField TxtField4;

    @FXML
    private TextField TxtField5;

    private ImplementacionOperacion operaciones = new ImplementacionOperacion();

    @FXML
    void actualizar(ActionEvent event) {
        Alert a = new Alert(AlertType.INFORMATION);
        try {
            String id = TxtField5.getText();
            Usuario usuarioExistente = operaciones.read(id);

            if (usuarioExistente == null) {
                a.setContentText("Usuario no encontrado con ID: " + id);
            } else {
                String nuevoNombre = TxtField1.getText();
                String nuevoEmail = TxtField2.getText();
                String nuevaDireccion = TxtField3.getText();
                String nuevoTelefono = TxtField4.getText();

                if (!nuevoNombre.isEmpty()) usuarioExistente.setNombre(nuevoNombre);
                if (!nuevoEmail.isEmpty()) usuarioExistente.setEmail(nuevoEmail);
                if (!nuevaDireccion.isEmpty()) usuarioExistente.setDireccion(nuevaDireccion);
                if (!nuevoTelefono.isEmpty()) usuarioExistente.setTelefono(nuevoTelefono);

                operaciones.update(usuarioExistente, id);
                a.setContentText("Usuario actualizado con éxito: " + usuarioExistente);
            }
        } catch (Exception e) {
            a.setContentText("Error al actualizar el usuario: " + e.getMessage());
        }
        a.show();
    }

    @FXML
    void crear(ActionEvent event) {
        Alert a = new Alert(AlertType.CONFIRMATION);

        try {
            String nombre = TxtField1.getText();
            String email = TxtField2.getText();
            String direccion = TxtField3.getText();
            String telefono = TxtField4.getText();
            String id = TxtField5.getText();

            if (nombre.isEmpty() || email.isEmpty() || direccion.isEmpty() || telefono.isEmpty() || id.isEmpty()) {
                a.setContentText("Todos los campos son obligatorios.");
                a.show();
                return;
            }

            Usuario nuevoUsuario = new Usuario(null, nombre, email, direccion, telefono, null, null, id);
            a.setContentText(operaciones.create(nuevoUsuario));
            a.show();

        } catch (Exception e) {
            a.setContentText("Error al crear el usuario: " + e.getMessage());
            a.show();
        }
    }

    @FXML
    void deserializar(ActionEvent event) {
        Alert a = new Alert(AlertType.INFORMATION);
        try {
            Usuario[] usuariosDeserializados = operaciones.deserializar("", "TextNoBinary1.txt");
            if (usuariosDeserializados != null) {
                operaciones.setUsuarios(usuariosDeserializados);
                a.setContentText("Usuarios deserializados con éxito.");
            } else {
                a.setContentText("No se pudieron deserializar los usuarios.");
            }
        } catch (Exception e) {
            a.setContentText("Error al deserializar: " + e.getMessage());
        }
        a.show();
    }

    @FXML
    void eliminar(ActionEvent event) {
        Alert a = new Alert(AlertType.INFORMATION);
        String idEliminar = TxtField5.getText();
        Usuario eliminado = operaciones.delete(idEliminar);
        if (eliminado != null) {
            a.setContentText("Usuario eliminado: " + eliminado);
        } else {
            a.setContentText("No se encontró el usuario con ID: " + idEliminar);
        }
        a.show();
    }

    @FXML
    void leer(ActionEvent event) {
        Alert a = new Alert(AlertType.INFORMATION);
        String idLeer = TxtField5.getText();
        Usuario usuario = operaciones.read(idLeer);
        if (usuario != null) {
            a.setContentText("Usuario encontrado: " + usuario);
        } else {
            a.setContentText("Usuario no encontrado con ID: " + idLeer);
        }
        a.show();
    }

    @FXML
    void lista(ActionEvent event) {
        Alert a = new Alert(AlertType.INFORMATION);
        Usuario[] usuarios = operaciones.readall();
        if (usuarios == null || usuarios.length == 0) {
            a.setContentText("No hay usuarios registrados.");
        } else {
            StringBuilder lista = new StringBuilder("Usuarios registrados:\n");
            for (Usuario usuario : usuarios) {
                if (usuario != null) {
                    lista.append(usuario).append("\n");
                }
            }
            a.setContentText(lista.toString());
        }
        a.show();
    }

    @FXML
    void salir(ActionEvent event) {
        Alert a = new Alert(AlertType.CONFIRMATION, "¿Está seguro de que desea salir?", ButtonType.YES, ButtonType.NO);
        a.showAndWait().ifPresent(response -> {
            if (response == ButtonType.YES) {
                Platform.exit();
            }
        });
    }

    @FXML
    void serializar(ActionEvent event) {
        Alert a = new Alert(AlertType.INFORMATION);
        try {
            String resultado = operaciones.serializar(operaciones.readall(), "", "TextNoBinary1.txt");
            a.setContentText(resultado);
        } catch (Exception e) {
            a.setContentText("Error al serializar: " + e.getMessage());
        }
        a.show();
    }
}
