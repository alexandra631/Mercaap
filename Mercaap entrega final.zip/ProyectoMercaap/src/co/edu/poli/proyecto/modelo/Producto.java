package co.edu.poli.proyecto.modelo;

import java.io.*;
import java.util.*;

/**
 * Representa un producto con detalles como nombre, descripcion, precio, cantidad disponible y categoria.
 */
public class Producto {

    /**
     * Nombre del producto.
     */
    private String nombre;

    /**
     * Descripcion del producto.
     */
    private String descripcion;

    /**
     * Precio del producto.
     */
    private Float precio;

    /**
     * Cantidad disponible del producto.
     */
    private int cantidadDisponible;

    /**
     * Categoria del producto.
     */
    private String Categoria;

    /**
     * Verifica la disponibilidad del producto dada una cantidad deseada.
     *
     * @param cantidad_deseada Cantidad deseada del producto.
     * @return true si la cantidad deseada esta disponible, false en caso contrario.
     */
    public boolean verificar_disponiblidad(int cantidad_deseada) {
        // TODO implement here
        return false;
    }

    /**
     * Constructor para crear un producto con los detalles especificos.
     *
     * @param nombre Nombre del producto.
     * @param descripcion Descripcion del producto.
     * @param precio Precio del producto.
     * @param cantidadDisponible Cantidad disponible del producto.
     * @param categoria Categoria del producto.
     */
    public Producto(String nombre, String descripcion, Float precio, int cantidadDisponible, String categoria) {
        super();
        this.nombre = nombre;
        this.descripcion = descripcion;
        this.precio = precio;
        this.cantidadDisponible = cantidadDisponible;
        this.Categoria = categoria;
    }

    /**
     * Obtiene el nombre del producto.
     *
     * @return El nombre del producto.
     */
    public String getNombre() {
        return nombre;
    }

    /**
     * Establece el nombre del producto.
     *
     * @param nombre Nuevo nombre del producto.
     */
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    /**
     * Obtiene la descripcion del producto.
     *
     * @return La descripcion del producto.
     */
    public String getDescripcion() {
        return descripcion;
    }

    /**
     * Establece la descripcion del producto.
     *
     * @param descripcion Nueva descripcion del producto.
     */
    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    /**
     * Obtiene el precio del producto.
     *
     * @return El precio del producto.
     */
    public Float getPrecio() {
        return precio;
    }

    /**
     * Establece el precio del producto.
     *
     * @param precio Nuevo precio del producto.
     */
    public void setPrecio(Float precio) {
        this.precio = precio;
    }

    /**
     * Obtiene la cantidad disponible del producto.
     *
     * @return La cantidad disponible del producto.
     */
    public int getCantidadDisponible() {
        return cantidadDisponible;
    }

    /**
     * Establece la cantidad disponible del producto.
     *
     * @param cantidadDisponible Nueva cantidad disponible del producto.
     */
    public void setCantidadDisponible(int cantidadDisponible) {
        this.cantidadDisponible = cantidadDisponible;
    }

    /**
     * Obtiene la categoria del producto.
     *
     * @return La categoria del producto.
     */
    public String getCategoria() {
        return Categoria;
    }

    /**
     * Establece la categoria del producto.
     *
     * @param categoria Nueva categoria del producto.
     */
    public void setCategoria(String categoria) {
        this.Categoria = categoria;
    }

    /**
     * Devuelve una representacion en cadena de la clase Producto.
     *
     * @return Representacion en cadena del objeto Producto.
     */
    @Override
    public String toString() {
        return "Producto [nombre=" + nombre + ", descripcion=" + descripcion + ", precio=" + precio
                + ", cantidadDisponible=" + cantidadDisponible + ", Categoria=" + Categoria + "]";
    }
}
