package co.edu.poli.proyecto.modelo;

import java.io.*;
import java.util.*;

/**
 * Representa un mercado con informacion sobre su nombre, ubicacion, fechas de inicio y fin, y sus productores.
 */
public class Mercado {

    /**
     * Nombre del mercado.
     */
    private String nombre;

    /**
     * Ubicacion del mercado.
     */
    private String ubicacion;

    /**
     * Fecha de inicio del mercado.
     */
    private String fechaInicio;

    /**
     * Fecha de fin del mercado.
     */
    private String fechaFin;

    /**
     * Productores asociados al mercado.
     */
    public Productor productores;

    /**
     * Genera un reporte de ventas para el mercado dentro de un rango de fechas especifico.
     *
     * @param fecha_inicio Fecha de inicio del periodo del reporte.
     * @param fecha_fin Fecha de fin del periodo del reporte.
     * @return Un reporte de ventas como una cadena de texto.
     */
    public String reporte_ventas(String fecha_inicio, String fecha_fin) {
        // TODO implement here
        return "";
    }

    /**
     * Constructor para crear un objeto Mercado con detalles especificos.
     *
     * @param nombre Nombre del mercado.
     * @param ubicacion Ubicacion del mercado.
     * @param fechaInicio Fecha de inicio del mercado.
     * @param fechaFin Fecha de fin del mercado.
     * @param productores Productores asociados al mercado.
     */
    public Mercado(String nombre, String ubicacion, String fechaInicio, String fechaFin, Productor productores) {
        super();
        this.nombre = nombre;
        this.ubicacion = ubicacion;
        this.fechaInicio = fechaInicio;
        this.fechaFin = fechaFin;
        this.productores = productores;
    }

    /**
     * Obtiene el nombre del mercado.
     *
     * @return El nombre del mercado.
     */
    public String getNombre() {
        return nombre;
    }

    /**
     * Establece el nombre del mercado.
     *
     * @param nombre Nuevo nombre del mercado.
     */
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    /**
     * Obtiene la ubicacion del mercado.
     *
     * @return La ubicacion del mercado.
     */
    public String getUbicacion() {
        return ubicacion;
    }

    /**
     * Establece la ubicacion del mercado.
     *
     * @param ubicacion Nueva ubicacion del mercado.
     */
    public void setUbicacion(String ubicacion) {
        this.ubicacion = ubicacion;
    }

    /**
     * Obtiene la fecha de inicio del mercado.
     *
     * @return La fecha de inicio del mercado.
     */
    public String getFechaInicio() {
        return fechaInicio;
    }

    /**
     * Establece la fecha de inicio del mercado.
     *
     * @param fechaInicio Nueva fecha de inicio del mercado.
     */
    public void setFechaInicio(String fechaInicio) {
        this.fechaInicio = fechaInicio;
    }

    /**
     * Obtiene la fecha de fin del mercado.
     *
     * @return La fecha de fin del mercado.
     */
    public String getFechaFin() {
        return fechaFin;
    }

    /**
     * Establece la fecha de fin del mercado.
     *
     * @param fechaFin Nueva fecha de fin del mercado.
     */
    public void setFechaFin(String fechaFin) {
        this.fechaFin = fechaFin;
    }

    /**
     * Obtiene los productores asociados al mercado.
     *
     * @return Los productores del mercado.
     */
    public Productor getProductores() {
        return productores;
    }

    /**
     * Establece los productores del mercado.
     *
     * @param productores Nuevos productores del mercado.
     */
    public void setProductores(Productor productores) {
        this.productores = productores;
    }

    /**
     * Devuelve una representacion en cadena de la clase Mercado.
     *
     * @return Representacion en cadena del objeto Mercado.
     */
    @Override
    public String toString() {
        return "Mercado [nombre=" + nombre + ", ubicacion=" + ubicacion + ", fechaInicio=" + fechaInicio + ", fechaFin="
                + fechaFin + ", productores=" + productores + "]";
    }
}
