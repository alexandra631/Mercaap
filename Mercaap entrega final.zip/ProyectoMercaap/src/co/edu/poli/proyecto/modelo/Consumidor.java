package co.edu.poli.proyecto.modelo;

import java.io.*;
import java.util.*;

/**
 * Representa un consumidor con un metodo de pago y la capacidad de calcular gastos mensuales.
 */
public class Consumidor {

    /**
     * Metodo de pago del consumidor.
     */
    private String metodo_pago;

    /**
     * Constructor para crear un consumidor con el metodo de pago especificado.
     *
     * @param metodo_pago Metodo de pago del consumidor.
     */
    public Consumidor(String metodo_pago) {
        super();
        this.metodo_pago = metodo_pago;
    }

    /**
     * Calcula los gastos mensuales de un consumidor dado un mes y un ano.
     *
     * @param mes Mes para el calculo de los gastos mensuales.
     * @param ano Ano para el calculo de los gastos mensuales.
     * @return El valor de los gastos mensuales.
     */
    public float calculara_gastos_mensuales(int mes, int ano) {
        // TODO implement here
        return 0.0f;
    }

    /**
     * Obtiene el metodo de pago del consumidor.
     *
     * @return Metodo de pago del consumidor.
     */
    public String getMetodo_pago() {
        return metodo_pago;
    }

    /**
     * Establece el metodo de pago del consumidor.
     *
     * @param metodo_pago Nuevo metodo de pago del consumidor.
     */
    public void setMetodo_pago(String metodo_pago) {
        this.metodo_pago = metodo_pago;
    }

    /**
     * Devuelve una representacion en cadena de la clase Consumidor.
     *
     * @return Representacion en cadena del objeto Consumidor.
     */
    @Override
    public String toString() {
        return "Consumidor [metodo_pago=" + metodo_pago + ", getMetodo_pago()=" + getMetodo_pago() + ", getClass()="
                + getClass() + ", hashCode()=" + hashCode() + ", toString()=" + super.toString() + "]";
    }
}
