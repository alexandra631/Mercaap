package co.edu.poli.proyecto.modelo;

import java.io.*;
import java.util.*;

/**
 * Representa un productor que tiene productos, ubicacion, metodo de produccion y una calificacion.
 */
public class Productor {

    /**
     * Producto producido o asociado al productor.
     */
    private Producto productos;

    /**
     * Ubicacion del productor.
     */
    private String ubicacion;

    /**
     * Metodo de produccion del productor.
     */
    private String metodoDeProduccion;

    /**
     * Calificacion del productor.
     */
    private Float calificacion;

    /**
     * Calcula los ingresos del productor en un rango de fechas especificado.
     *
     * @param fecha_inicio Fecha de inicio del periodo de calculo.
     * @param fecha_fin Fecha de fin del periodo de calculo.
     * @return Una cadena que representa los ingresos calculados.
     */
    public String calcular_ingresos(float fecha_inicio, String fecha_fin) {
        // TODO implement here
        return "";
    }

    /**
     * Constructor para crear un productor con detalles especificos.
     *
     * @param productos Producto asociado al productor.
     * @param ubicacion Ubicacion del productor.
     * @param metodoDeProduccion Metodo de produccion del productor.
     * @param calificacion Calificacion del productor.
     */
    public Productor(Producto productos, String ubicacion, String metodoDeProduccion, Float calificacion) {
        super();
        this.productos = productos;
        this.ubicacion = ubicacion;
        this.metodoDeProduccion = metodoDeProduccion;
        this.calificacion = calificacion;
    }

    /**
     * Obtiene el producto asociado al productor.
     *
     * @return El producto del productor.
     */
    public Producto getProductos() {
        return productos;
    }

    /**
     * Establece el producto del productor.
     *
     * @param productos Nuevo producto asociado al productor.
     */
    public void setProductos(Producto productos) {
        this.productos = productos;
    }

    /**
     * Obtiene la ubicacion del productor.
     *
     * @return La ubicacion del productor.
     */
    public String getUbicacion() {
        return ubicacion;
    }

    /**
     * Establece la ubicacion del productor.
     *
     * @param ubicacion Nueva ubicacion del productor.
     */
    public void setUbicacion(String ubicacion) {
        this.ubicacion = ubicacion;
    }

    /**
     * Obtiene el metodo de produccion del productor.
     *
     * @return El metodo de produccion del productor.
     */
    public String getMetodoDeProduccion() {
        return metodoDeProduccion;
    }

    /**
     * Establece el metodo de produccion del productor.
     *
     * @param metodoDeProduccion Nuevo metodo de produccion del productor.
     */
    public void setMetodoDeProduccion(String metodoDeProduccion) {
        this.metodoDeProduccion = metodoDeProduccion;
    }

    /**
     * Obtiene la calificacion del productor.
     *
     * @return La calificacion del productor.
     */
    public Float getCalificacion() {
        return calificacion;
    }

    /**
     * Establece la calificacion del productor.
     *
     * @param calificacion Nueva calificacion del productor.
     */
    public void setCalificacion(Float calificacion) {
        this.calificacion = calificacion;
    }

    /**
     * Devuelve una representacion en cadena de la clase Productor.
     *
     * @return Representacion en cadena del objeto Productor.
     */
    @Override
    public String toString() {
        return "Productor [productos=" + productos + ", ubicacion=" + ubicacion + ", metodoDeProduccion="
                + metodoDeProduccion + ", calificacion=" + calificacion + ", getProductos()=" + getProductos()
                + ", getUbicacion()=" + getUbicacion() + ", getMetodoDeProduccion()=" + getMetodoDeProduccion()
                + ", getCalificacion()=" + getCalificacion() + ", getClass()=" + getClass() + ", hashCode()="
                + hashCode() + ", toString()=" + super.toString() + "]";
    }
}
