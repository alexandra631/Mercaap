package co.edu.poli.proyecto.modelo;

import java.io.*;
import java.util.*;

/**
 * Representa un usuario que extiende la funcionalidad de Consumidor e implementa Serializable, con atributos de informacion personal.
 */
public class Usuario extends Consumidor implements Serializable {
    private static final long serialVersionUID = 1L;

    /**
     * Nombre del usuario.
     */
    private String nombre;

    /**
     * Email del usuario.
     */
    private String email;

    /**
     * Direccion del usuario.
     */
    private String direccion;

    /**
     * Telefono del usuario.
     */
    private String telefono;

    /**
     * Productor asociado al usuario.
     */
    private Productor productor;

    /**
     * Consumidor asociado al usuario.
     */
    private Consumidor consumidor;

    /**
     * Identificacion del usuario.
     */
    private String Id;

    /**
     * Permite editar el perfil del usuario.
     *
     * @return Cadena representando el resultado de la edicion del perfil.
     */
    public String editar_perfil() {
        // TODO implement here
        return "";
    }

    /**
     * Obtiene el nombre del usuario.
     *
     * @return El nombre del usuario.
     */
    public String getNombre() {
        return nombre;
    }

    /**
     * Establece el nombre del usuario.
     *
     * @param nombre Nuevo nombre del usuario.
     */
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    /**
     * Obtiene el email del usuario.
     *
     * @return El email del usuario.
     */
    public String getEmail() {
        return email;
    }

    /**
     * Establece el email del usuario.
     *
     * @param email Nuevo email del usuario.
     */
    public void setEmail(String email) {
        this.email = email;
    }

    /**
     * Obtiene la direccion del usuario.
     *
     * @return La direccion del usuario.
     */
    public String getDireccion() {
        return direccion;
    }

    /**
     * Establece la direccion del usuario.
     *
     * @param direccion Nueva direccion del usuario.
     */
    public void setDireccion(String direccion) {
        this.direccion = direccion;
    }

    /**
     * Obtiene el telefono del usuario.
     *
     * @return El telefono del usuario.
     */
    public String getTelefono() {
        return telefono;
    }

    /**
     * Establece el telefono del usuario.
     *
     * @param telefono Nuevo telefono del usuario.
     */
    public void setTelefono(String telefono) {
        this.telefono = telefono;
    }

    /**
     * Obtiene el productor asociado al usuario.
     *
     * @return El productor del usuario.
     */
    public Productor getProductor() {
        return productor;
    }

    /**
     * Establece el productor asociado al usuario.
     *
     * @param productor Nuevo productor del usuario.
     */
    public void setProductor(Productor productor) {
        this.productor = productor;
    }

    /**
     * Obtiene el consumidor asociado al usuario.
     *
     * @return El consumidor del usuario.
     */
    public Consumidor getConsumidor() {
        return consumidor;
    }

    /**
     * Establece el consumidor asociado al usuario.
     *
     * @param consumidor Nuevo consumidor del usuario.
     */
    public void setConsumidor(Consumidor consumidor) {
        this.consumidor = consumidor;
    }

    /**
     * Obtiene la identificacion del usuario.
     *
     * @return La identificacion del usuario.
     */
    public String getId() {
        return Id;
    }

    /**
     * Establece la identificacion del usuario.
     *
     * @param id Nueva identificacion del usuario.
     */
    public void setId(String id) {
        Id = id;
    }

    /**
     * Devuelve una representacion en cadena de la clase Usuario.
     *
     * @return Representacion en cadena del objeto Usuario.
     */
    @Override
    public String toString() {
        return "Usuario [nombre=" + nombre + ", email=" + email + ", direccion=" + direccion + ", telefono=" + telefono
                + ", productor=" + productor + ", consumidor=" + consumidor + ", Id=" + Id + "]";
    }

    /**
     * Constructor para crear un usuario con detalles especificos.
     *
     * @param metodo_pago Metodo de pago del usuario como Consumidor.
     * @param nombre Nombre del usuario.
     * @param email Email del usuario.
     * @param direccion Direccion del usuario.
     * @param telefono Telefono del usuario.
     * @param productor Productor asociado al usuario.
     * @param consumidor Consumidor asociado al usuario.
     * @param id Identificacion del usuario.
     */
    public Usuario(String metodo_pago, String nombre, String email, String direccion, String telefono,
                   Productor productor, Consumidor consumidor, String id) {
        super(metodo_pago);
        this.nombre = nombre;
        this.email = email;
        this.direccion = direccion;
        this.telefono = telefono;
        this.productor = productor;
        this.consumidor = consumidor;
        this.Id = id;
    }
}
